"use strict";

function crudList_CGF() {

    var coffeeListDiv = document.createElement("div");

    coffeeListDiv.className = "crudList";

    ajax("json/coffeeProductsEdit.json", processCoffeeList, coffeeListDiv);

    function processCoffeeList(coffeeList) {
        var userInputSpecs = [
            {
                "prompt": "Name Coffee (required, length 5..20): ",
                "fieldName": "name",
                "dataType": "string",
                "isRequired": true,
                "minLen": 5,
                "maxLen": 20
            },
            {
                "prompt": "Coffee Image (URL): ",
                "fieldName": "image",
                "dataType": "string",
                "minLen": 0,
                "maxLen": 500
            },
            {
                "prompt": "Enter Espresso Shot Count (required 1 to 10): ",
                "fieldName": "espressoCount",
                "dataType": "integer",
                "isRequired": true,
                "minLen": 1,
                "maxLen": 10
            },
            {
                "prompt": "Price (Required, value must be 1..50): ",
                "fieldName": "price",
                "dataType": "number",
                "isRequired": true,
                "min": 1,
                "max": 50
            },
            {
                "prompt": "Roast Date (Required...): ",
                "fieldName": "roastDate",
                "dataType": "date",
                "isRequired": true
            },
            {
                "prompt": "Expiration Date (Not Required - Optional): ",
                "fieldName": "expirationDate",
                "dataType": "date",
                "isRequired": false
            },
            {
                "prompt": "Brewing Method(Default): ",
                "fieldName": "brewingMethod",
                "dataType": "radio",
                "isRequired": false,
                "choices": ["French Press", "Pour Over", "Espresso Machine", "Cold Brew"],
                "selected": "Espresso Machine"
            },
            {
                "prompt": "Cup Size ( With Default Value Required): ",
                "fieldName": "cupSize",
                "dataType": "select",
                "isRequired": false,
                "choices": ["Small (8 oz)", "Medium (12 oz)", "Large (16 oz)", "Extra Large (20 oz)"],
                "selected": "Medium (12 oz)"
            },
            {
                "prompt": "Cup Size (Without Default Value - Required): ",
                "fieldName": "cupSize2",
                "dataType": "select",
                "isRequired": true,
                "choices": ["", "Small (8 oz)", "Medium (12 oz)", "Large (16 oz)", "Extra Large (20 oz)"],
                "selected": ""
            }
        ];



        var displayTemplate =
            "<div class='ele'>" +
            "<div class='eleInfo'>" +
            "<img src='${obj.image}' alt='${obj.name}' class='coffee-image' />" +
            "<div>" +
            "<h4>${obj.name}</h4>" +
            "<div class='row'><label class='prompt'>Espresso Shots:</label><p>${obj.espressoCount}</p></div>" +
            "<div class='row'><label class='prompt'>Price:</label><p>$${obj.price}</p></div>" +
            "<div class='row'><label class='prompt'>Roast Date:</label><p>${obj.roastDate}</p></div>" +
            "<div class='row'><label class='prompt'>Expiration Date:</label><p>${obj.expirationDate ? obj.expirationDate : 'N/A'}</p></div>" +
            "<div class='row'><label class='prompt'>Brewing Method:</label><p>${obj.brewingMethod}</p></div>" +
            "<div class='row'><label class='prompt'>Cup Size:</label><p>${obj.cupSize}</p></div>" +
            "</div>" +
            "</div>" +
            "</div>";


        // 💡 These lines must be INSIDE processCoffeeList
        coffeeListDiv.appendChild(MakeCrudList({
            title: "Welcome To My Coffee Product",
            objList: coffeeList,
            inputSpecs: userInputSpecs,
            displayTemplate: displayTemplate
        }));

    }


    ajax("json/CoffeeBeansEdit.json", processBeanList, coffeeListDiv);

    function processBeanList(beanList) {

        var userInputSpecs = [
            {
                "prompt": "Bean Variety (3-50 character, Required, such as: Ethiopian Yirgacheffe...): ",
                "fieldName": "beanVariety",
                "dataType": "string",
                "isRequired": true,
                "minLen": 3,
                "maxLen": 50
            },
            {
                "prompt": "Harvest Date (Required): ",
                "fieldName": "harvestDate",
                "dataType": "date",
                "isRequired": true
            },
            {
                "prompt": "Packaging Date (Optional): ",
                "fieldName": "packagingDate",
                "dataType": "date",
                "isRequired": false
            },
            {
                "prompt": "Acidity Level (Required, 1-10, such as: 3, 8.5, 10,...): ",
                "fieldName": "acidityLevel",
                "dataType": "number",
                "isRequired": true,
                "min": 1,
                "max": 10
            },
            {
                "prompt": "Bean Count (Integer, 100-5000, Required): ",
                "fieldName": "beanCount",
                "dataType": "integer",
                "isRequired": true,
                "min": 100,
                "max": 5000
            },
            {
                "prompt": "Processing Method (Required with default): ",
                "fieldName": "processingMethod",
                "dataType": "radio",
                "isRequired": false,
                "choices": ["Washed", "Natural", "Honey Process"],
                "selected": "Natural"
            },

            {
                "prompt": "Processing Method2 (Required without default): ",
                "fieldName": "processingMethod2",
                "dataType": "radio",
                "isRequired": true,
                "choices": ["Washed", "Natural", "Honey Process"],
                "selected": ""
            },

            {
                "prompt": "Grind Size (Required with Default): ",
                "fieldName": "grindSize",
                "dataType": "select",
                "isRequired": false,
                "choices": ["Fine", "Medium", "Coarse"],
                "selected": "Medium"
            },
            {
                "prompt": "Coffee Image (URL): ",
                "fieldName": "image",
                "dataType": "string",
                "minLen": 0,
                "maxLen": 500
            }

        ];

        var displayTemplate =
            "<div class='ele'>" +
            "<div class='eleInfo'>" +
            "<img src='${obj.image || \"default.jpg\"}' alt='${obj.beanVariety}' class='coffee-image' />" +
            "<div>" +
            "<h4>${obj.beanVariety}</h4>" +
            "<div class='row'><label class='prompt'>Harvest Date:</label><p>${obj.harvestDate}</p></div>" +
            "<div class='row'><label class='prompt'>Packaging Date:</label><p>${obj.packagingDate ? obj.packagingDate : 'N/A'}</p></div>" +
            "<div class='row'><label class='prompt'>Acidity Level:</label><p>${obj.acidityLevel}</p></div>" +
            "<div class='row'><label class='prompt'>Bean Count:</label><p>${obj.beanCount}</p></div>" +
            "<div class='row'><label class='prompt'>Processing Method:</label><p>${obj.processingMethod}</p></div>" +
            "<div class='row'><label class='prompt'>Processing Method 2:</label><p>${obj.processingMethod2}</p></div>" +
            "<div class='row'><label class='prompt'>Grind Size:</label><p>${obj.grindSize}</p></div>" +
            "</div></div></div>";



        // 💡 These lines must be INSIDE processCoffeeList
        coffeeListDiv.appendChild(MakeCrudList({
            title: "Welcome To My Bean Product",
            objList: beanList,
            inputSpecs: userInputSpecs,
            displayTemplate: displayTemplate
        }));

    }

        // These CGF will be call the Empty/ Untitle project

        coffeeListDiv.appendChild(MakeCrudList({}))



    return coffeeListDiv;
}