"use strict"
function UsersComingSoonJS() {

    var ele = document.createElement("div");
    ele.classList.add("usersComingSoon");
    ele.innerHTML = `
        <h3>Users Coming Soon (JS) </h3>
        <p>Our user page is under construction. Check back soon for updates!</p>
        `;
    return ele;
}
