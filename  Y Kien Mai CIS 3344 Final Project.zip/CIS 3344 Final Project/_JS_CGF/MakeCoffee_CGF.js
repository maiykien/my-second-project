"use strict"; // Enables strict mode to catch common coding errors and enforce better practices.

function MakeCoffee_CGF() { // Defines a function that creates and returns a container with multiple coffee objects.

    var ele = document.createElement("div"); // Creates a new div element to act as a container for multiple coffee elements.

    // Creates a coffee object with specific properties using the MakeCoffee function.
    var myCoff = MakeCoffee({
        nameCoffee: "Espresso Nirvana", // Sets the coffee name.
        imageURL: "pics/EspressoNirvana.jpg", // Sets the image source for the coffee.
        price: 7.99, // Sets the price of the coffee.
        description: "Espresso Mindfulness Make Good Mental",
        coffeeList: [
            { "display": "Espresso Mindset", "val": "pics/EspressoNirvana.jpg" },
            { "display": "Zen Espresso", "val": "pics/ZenEspresso.jpg" },
            { "display": "Mindful Brew Espresso", "val": "pics/MindfulBrewEspresso.jpg" },
            { "display": "Serene Shots Espresso", "val": "pics/SereneShotsEspresso.jpg" }
        ],
        initialCoffeeCondition:3
    });

    ele.appendChild(myCoff); // Appends the created coffee element to the main div container

    var myCoff1 = MakeCoffee({
        nameCoffee: "Calm Brew Macchiato", 
        imageURL: "pics/coffeemachiato.jpg", 
        price: 8.99, 
        description: "Sip, Savor, Be Present.", 
        coffeeList: [
            { "display": " Calm Macchiato", "val": "pics/coffeemachiato.jpg"},
            { "display": " Serenity Macchiato", "val": "pics/SerenityMacchiato.jpg"},
            { "display": "Calm Brew Macchiato", "val": "pics/CalmBrewMacchiato.jpg" },
            { "display": "Zen-Infused Macchiato", "val": "pics/ZenMacchiato.jpg" }
        ],

        initialCoffeeCondition:22

    });

    ele.appendChild(myCoff1); // Appends the created coffee element to the main div container.

    // Creates a coffee object with default values by calling MakeCoffee with an empty object. 
    var myCoff3 = MakeCoffee({});
    ele.appendChild(myCoff3); // Appends the default coffee to the main div container. 

    return ele; // Returns the container div holding all the coffee elements.
}
