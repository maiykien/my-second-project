"use strict"; // Prevent Browswer from globally auto declaring variables.

// Function to create a coffee list component withd data fetched from JSON file
function MakeCoffeeList_CGF(){

    var ele = document.createElement("div"); // Create the new div element to hold the coffee
    
    ajax("json/coffeeProductsEnhanced.json", coffComp1, ele);

     // Using the first Json
    function coffComp1(coff1List) 
    {
        var CoffeeListUpdated = []; // We will do it without map function
        for (var coff of coff1List) {

            CoffeeListUpdated.push({

                nameCoffee: coff.name,
                imageURL: coff.image,
                price: coff.price,
                description: coff.description,
                coffeeImageList: coff.pics

            });
        }

        // Create a coffee list component with updated coffee data

        var CoffComp = MakeCoffeeList({
            coffeeList: CoffeeListUpdated,
            title: "All My First Product Meditation Coffee",
            styleCoffee: "Zen Coffee Meditation"
        });

        ele.appendChild(CoffComp); // Append the created component to the main div
    }


    // This is for using the second Json. 
    ajax("json/CoffeeBeansEnhanced.json", coffComp2, ele);

    function coffComp2(coff2List) 
    {
        var CoffeeList2Updated = []; // We will do it without map function
        for (var coff of coff2List) {
            
            // This one for update the coffeelist2
            CoffeeList2Updated.push({

                nameCoffee: coff.name, 
                imageURL: coff.image,
                price: coff.price,
                description: coff.description,
                coffeeImageList: coff.pics

            });
        }

        var Coff2Comp = MakeCoffeeList({
            coffeeList: CoffeeList2Updated,
            title: " My Second Product Mindfulness Coffee Beans",
            styleCoffee: "Coffee Bean Meditation"
        });

        ele.appendChild(Coff2Comp);
    }

    var defaultCoffComp = MakeCoffeeList({});
    ele.appendChild(defaultCoffComp);

   
    return ele;

    }




