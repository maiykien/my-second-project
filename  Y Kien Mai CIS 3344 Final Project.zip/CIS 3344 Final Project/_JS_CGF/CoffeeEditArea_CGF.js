"use strict";

// Function to create the Coffee Edit Area Component
function CoffeeEditArea_CGF() {
    
    var ele = document.createElement("div");

    ele.innerHTML = `
                  <div class="editAreaC">
                   <h4>Edit Coffee Details</h4>
                    <h4>Message Coffee Area</h4>
                  </div>

                  <div class="msgAreaC"></div>
                `;

    var editArea = ele.getElementsByClassName("editAreaC")[0];
    var msgArea = ele.getElementsByClassName("msgAreaC")[0];

    var userInputSpecs = [
        // for String
        {
            "prompt": "Name Coffee (required, length 5..20): ",
            "fieldName": "nameCoffee",
            "dataType": "string",
            "isRequired": true,
            "minLen": 5,
            "maxLen": 20
        },


        // For integer
        {
            "prompt": "Enter Espresso Shot Count (required 1 to 10): ",
            "fieldName": "EspressoCount",
            "dataType": "integer",
            "isRequired": true,
            "minLen": 1,
            "maxLen": 10
        },

        // For number
        {
            "prompt": "Price (Required, value must be 1..50): ",
            "fieldName": "price",
            "dataType": "number",
            "isRequired": true,
            "min": 1,
            "max": 50
        },

        // date with required 
        {
            "prompt": "Roast Date (Required...): ",
            "fieldName": "roastDate",
            "dataType": "date",
            "isRequired": true
        },

        // date with optional
        {
            "prompt": "Expiration Date (Not Required - Optional): ",
            "fieldName": "expirationDate",
            "dataType": "date",
            "isRequired": false
        },

        // Radio Button with  Default
        {
            "prompt": "Brewing Method(Default): ",
            "fieldName": "brewingMethod",
            "dataType": "radio",
            "isRequired": false,
            "choices": [ "French Press", "Pour Over", "Espresso Machine", "Cold Brew" ],
            "selected": "Espresso Machine"  // Default selected value
        },
      

        //Radio Button without default
        {
            "prompt": "Brewing Method(Without Default): ",
            "fieldName": "brewingMethod2",
            "dataType": "radio",
            "isRequired": true,
            "choices": [ "French Press", "Pour Over", "Espresso Machine", "Cold Brew" ],
            "selected": ""  // Default selected value
        },

        //Select list with default value specified
        {
            "prompt": "Cup Size ( With Default Value Required): ",
            "fieldName": "cupSize",
            "dataType": "select",
            "isRequired": false,
            "choices": ["Small (8 oz)", "Medium (12 oz)", "Large (16 oz)", "Extra Large (20 oz)"],
            "selected": "Medium (12 oz)"  // Default selected value
        },

        // Select list without default values
        {
            "prompt": "Cup Size (Without Default Value - Required): ",
            "fieldName": "cupSize2",
            "dataType": "select",
            "isRequired": true,
            "choices": ["", "Small (8 oz)", "Medium (12 oz)", "Large (16 oz)", "Extra Large (20 oz)"],
            "selected": ""  // Default selected value
        },



    ];

    var userToEdit = {
        "nameCoffee": "Mocha Macchiato",
        "EspressoCount": 2,
        "price": 4.99,
        "roastDate": "2024-03-10",
        "expirationDate": "",
        "brewingMethod": "",
        "brewingMethod2": "",
        "cupSize": ""
    };

    function success(inpObj) {
        msgArea.innerHTML += "The below is information about Coffee Meditation Edit Area:<br/>";
        for (var propName in inpObj) {
            msgArea.innerHTML += "&nbsp; &nbsp; " + propName + ": " +
                inpObj[propName] + "<br/>";
        }
        msgArea.innerHTML += "<br/>";
    }

    function cancel() {
        msgArea.innerHTML += "You're canceled it! <br/><br/>";
    }

    // Create and append the edit area component
    var component = MakeEditArea({
        inputSpecs: userInputSpecs,
        successCallBack: success,
        cancelCallBack: cancel,
        editObj: userToEdit
    });

    editArea.appendChild(component);


    return ele;

    document.getElementById("content").appendChild(CoffeeEditArea_CGF());

}



// Add the component to the page after the function is defined
