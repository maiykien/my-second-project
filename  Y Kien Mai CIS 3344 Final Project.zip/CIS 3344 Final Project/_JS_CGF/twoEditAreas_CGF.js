"use strict";

function twoEditAreas_CGF(){

    var ele = document.createElement("div");
    ele.appendChild(CoffeeEditArea_CGF());
    ele.appendChild(EmptyCoffeeArea_CGF());
    return ele;
    
}