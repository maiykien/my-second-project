"use strict";

// Function to create a slide show container with multiple sections
function SlideShow_CGF() {

    ////////////////////////////////////////////////////////////////

    // Creating a container element
    var container = document.createElement("div");

    // Setting the innerHTML for the container
    container.innerHTML = `
    <div class="firstShow"></div>
    <div class="secondShow"></div>
    <div class="thirdShow"></div>
  `;

    // This is getting references to the three sections
    var firstDiv = container.getElementsByClassName("firstShow")[0];
    var secondDiv = container.getElementsByClassName("secondShow")[0];
    var thirdDiv = container.getElementsByClassName("thirdShow")[0];



    // Calling ajax to fetch the coffee products JSON
    ajax("json/coffeeProducts.json", processCoffeeProductList, firstDiv);

    // This is the callback function to process the response from AJAX
    function processCoffeeProductList(jsonCoffeeProductList) {
        console.log("Original coffee list from JSON file below:");
       console.log(jsonCoffeeProductList);

        // Process the list to fit the structure expected by MakeSlideShow
        var newCoffeeList = [];
        for (var coffee of jsonCoffeeProductList) {
            newCoffeeList.push({
                imageURL: coffee.image,
                caption: coffee.name,
                infor: `Price: ${coffee.price} Category: ${coffee.category}`
            });
        }

        console.log("New coffee list with image, caption, otherInfo properties:");
        console.log(newCoffeeList);

        // Now, you can call MakeSlideShow with the processed list
        var slideShow = MakeSlideShow({
            title: "Welcome To My Coffee Meditation Shop",
            picObjList: newCoffeeList,
            transitionEffect: "fade"
        });

        // Append the slide show to the firstDiv
        firstDiv.appendChild(slideShow);
    }

    // Fetching coffee bean data and processing it. 
    ajax("json/CoffeeBeans.json", processBeansList, secondDiv);

    // Callback function to process the coffee bean list received from AJAX
    function processBeansList(jsonBeanList){
        console.log("Original coffee list from JSON File below: ");
        console.log(jsonBeanList);

        var newBeanList = [];

        // Process JSON data to match the format expected by MakeSlideShow
        for(var bean of jsonBeanList){
            newBeanList.push({
                imageURL: bean.image,
                caption: bean.name,
                infor: `Price: ${bean.price} Description: ${bean.description}`
            });
        }

        console.log("Hello");

         var slideShow1 = MakeSlideShow({
            title: "Welcome To My Bean Shop",
            picObjList: newBeanList,
            transitionEffect: "fade"
        });
        // Append the generated slideshow to the second section
        secondDiv.appendChild(slideShow1);
    }

    // Create a default slideshow with default images and settings
    var slideShow2 = MakeSlideShow({})
    thirdDiv.appendChild(slideShow2)

    return container; // Return the complete container with slideshows. 
}