
    // Added the Ajax function on the top of the website. 
    function ajax(url, successCallBackFn, errorEle) {
        var httpReq;
        if (window.XMLHttpRequest) {
            httpReq = new XMLHttpRequest(); //For Firefox, Safari, Opera
        } else if (window.ActiveXObject) {
            httpReq = new ActiveXObject("Microsoft.XMLHTTP"); //For IE 5+
        } else {
            errorEle.innerHTML += "old browser -- ajax not supported";
            return;
        }

        console.log("ready to get content " + url);
        httpReq.open("GET", url); // specify which page you want to get

        // Define the function that the browser will call back when the data is available.
        httpReq.onreadystatechange = function () {
            if (httpReq.readyState === 4) {     // 4 means that the data transfer is complete
                console.log("in ajax, status is " + httpReq.status);

                if (httpReq.status === 200) {   // 200 means file found (unlike 404 which means not found)
                    console.log("in ajax, js object printed next");

                    var obj = JSON.parse(httpReq.responseText);
                    console.log(obj);

                    successCallBackFn(obj); // Call the success callback function
                } else {  // error, file not found
                    errorEle.innerHTML += "Error " + httpReq.status + "-" + httpReq.statusText +
                        " while attempting to read '" + url + "'";
                }
            }
        };

        httpReq.send(null); // initiate ajax call
        console.log("call initiated");
    }
