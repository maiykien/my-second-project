"use strict";

function EmptyCoffeeArea_CGF() {
    var ele = document.createElement("div");

    ele.innerHTML = `
        <div class="editAreaC">
            <h4>Empty Coffee Area</h4>
            <h4>Message Area</h4>
        </div>
        <div class="msgAreaC"></div>
    `;

    var editArea = ele.getElementsByClassName("editAreaC")[0];
    var msgArea = ele.getElementsByClassName("msgAreaC")[0];

    var userInputSpecs = [
        {
            "prompt": "Bean Variety (3-50 character, Required, such as: Ethiopian Yirgacheffe...): ",
            "fieldName": "beanVariety",
            "dataType": "string",
            "isRequired": true,
            "minLen": 3,
            "maxLen": 50
        },
        {
            "prompt": "Harvest Date (Required): ",
            "fieldName": "harvestDate",
            "dataType": "date",
            "isRequired": true
        },
        {
            "prompt": "Packaging Date (Optional): ",
            "fieldName": "packagingDate",
            "dataType": "date",
            "isRequired": false
        },
        {
            "prompt": "Acidity Level (Required, 1-10, such as: 3, 8.5, 10,...): ",
            "fieldName": "acidityLevel",
            "dataType": "number",
            "isRequired": true,
            "min": 1,
            "max": 10
        },
        {
            "prompt": "Bean Count (Integer, 100-5000, Required): ",
            "fieldName": "beanCount",
            "dataType": "integer",
            "isRequired": true,
            "min": 100,
            "max": 5000
        },
        {
            "prompt": "Processing Method (Required with default): ",
            "fieldName": "processingMethod",
            "dataType": "radio",
            "isRequired": false,
            "choices": ["Washed", "Natural", "Honey Process"],
            "selected": "Natural"
        },

        {
            "prompt": "Processing Method2 (Required without default): ",
            "fieldName": "processingMethod2",
            "dataType": "radio",
            "isRequired": true,
            "choices": ["Washed", "Natural", "Honey Process"],
            "selected": ""
        },

        {
            "prompt": "Grind Size (Required with Default): ",
            "fieldName": "grindSize",
            "dataType": "select",
            "isRequired": false,
            "choices": ["Fine", "Medium", "Coarse"],
            "selected": "Medium"
        },

        {
            "prompt": "Grind Size (Required without Default): ",
            "fieldName": "grindSize2",
            "dataType": "select",
            "isRequired": true,
            "choices": ["", "Fine", "Medium", "Coarse"],
            "selected": ""
        },



    ];

    //Empty User. 
    var newUser = { };

    function success(inpObj) {
        msgArea.innerHTML += "Your information you entered has been show on the below :<br/>";
        for (var propName in inpObj) {
            msgArea.innerHTML += "&nbsp; &nbsp; " + propName + ": " +
                inpObj[propName] + "<br/>";
        }
        msgArea.innerHTML += "<br/>";
    }

    function cancel() {
        msgArea.innerHTML += "You canceled it. <br/><br/>";
    }

    var component = MakeEditArea({
        inputSpecs: userInputSpecs,
        successCallBack: success,
        cancelCallBack: cancel,
        editObj: newUser
    });

    editArea.appendChild(component);

    return ele;

    // Append the component to the page after everything is ready
    document.getElementById("content").appendChild(EmptyCoffeeArea_CGF());
    
} 