"use strict" // Ensures the script runs in strict mode. 

function MakeCoffee1_CGF() {
    // Array of espresso-related images with display names and URLs.
    var espressoPics = [
        { display: "Espresso Nirvana", val: "https://live.staticflickr.com/4769/24814515407_5230b92e9f_b.jpg"},
        { display: "Zen Espresso", val: "https://thezenleaf.com/wp-content/uploads/2020/04/03-morning-coffee.jpg" },
        { display: "Mindful Brew Espresso", val: "https://i.etsystatic.com/41414149/r/il/43242a/5767152244/il_570xN.5767152244_iiwo.jpg"}

    ];
    
    // Arrays of machiato image with display name and URLs
    var macchiatoPics = [
        { display: "Calm Brew Macchiato", val:"https://img.freepik.com/premium-photo/realistic-coffee-photo-latte-art-calm-mood_946110-23982.jpg"},
        { display: "Serenity Macchiato", val: "https://d1r9hss9q19p18.cloudfront.net/uploads/2024/06/resep-kopi-viral-aerocano.jpg" },
        { display: "Calm Brew Macchiato", val: "https://globalassets.starbucks.com/digitalassets/products/bev/SBX20181116_IcedCaramelMacchiato.jpg"}
    ];

    return (
        
        <div>
            {/* That would rendering the coffee component for Espresso Nirvana*/}
            <MakeCoffee1 
                nameCoffee="Espresso Nirvana"
                imageURL="https://live.staticflickr.com/4769/24814515407_5230b92e9f_b.jpg"
                Theprice={3.99}
                Thedescription="Strong, bold, rich, concentrated, smooth."
                coffeeList={espressoPics}
            />
            {/* Rendering a coffee component for Calm Brew Macchiato */}
            <MakeCoffee1 
                nameCoffee="Calm Brew Macchiato"
                imageURL= "https://globalassets.starbucks.com/digitalassets/products/bev/SBX20181116_IcedCaramelMacchiato.jpg"
                Theprice={4.99}
                Thedescription="Sip, Savor, Be Present."
                coffeeList={macchiatoPics}
            />
            {/* Rendering a default coffee component without props */}
            <MakeCoffee1 />
            
        </div>
    );
}