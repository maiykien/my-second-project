
"use strict"; // Prevent the browser.
function CoffeeListR_CGF() {
    return (
        <div>
            <FirstCoffeeListR_CGF />
            <SecondCoffeeListR_CGF />
            <MakeCoffeeListR />
        </div>
    )
}