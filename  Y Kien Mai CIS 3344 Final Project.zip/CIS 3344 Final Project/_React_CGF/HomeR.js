"use strict" // I will put the Enforces strict mode, which helps catch common coding mistakes and prevents the use of undeclared variables.
function HomeR() { // Defines a React functional component named HomeR
    return (
        <div className="home">
            <h4>
                Hello, Welcome To My Coffee Mediation Shop. 
            </h4>

            <img
                src="pics/coffeemeditation.jpg" // Specifies the path to the image file.
                alt="Coffee Meditation" // Alternatives text for accessibility in case the image fails to load.
            />
            <p>
                Coffee Meditation is a space where coffee meets mindfulness, transforming an everyday ritual into a moment of peace, energy, and inspiration.
                More than just a beverage, coffee is an experience—an opportunity to slow down, savor the aroma, and embrace the present moment.
                This is the website I built with one purpose: to inspire others to discover the joy and energy that <strong> brings to life.</strong>
                Here, coffee is more than just a drink and it’s an experience, a moment to pause, reflect, and recharge.
                Whether you are here to explore premium coffee products, learn brewing techniques, or simply find a spark of happiness in your daily routine, this website is your gateway to a mindful coffee journey.
                Click <a href="https://taurfeine.com/" > Explore Coffee Meditation </a>
            </p>
            <p>
                At Coffee Meditation, coffee is more than just a drink—it’s an experience, a ritual, and a moment of mindfulness in a busy world.
                This website was created with one purpose: to inspire others to discover the joy, energy, and clarity that coffee brings to life.
                In a fast-paced world, coffee can be a pause button, a chance to reflect, reset, and find balance. Whether you're here to enhance your brewing skills,
                explore new coffee products, or simply find inspiration in everyday moments, Coffee Meditation is your gateway to a more mindful coffee journey.
            </p>

        </div>

    );
}