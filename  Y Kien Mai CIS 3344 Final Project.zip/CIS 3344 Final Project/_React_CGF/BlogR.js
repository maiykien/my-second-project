"use strict"
function BlogR() { // Defines a React functional component named BlogR.
    return (
        <div className="blog">

            <h3>Blog Explain My Website Data</h3>
            <img
                src="pics/coffeemeditation1.jpg" // Specifies the image source file path
                alt="Success Image" // Provides alternative text for the image
            />
            <h4>About My Website</h4> { }
            <p>
                This is my blogs website revolves around coffee-related information, reflecting the theme of "The Art of Coffee". This data includes details about different types of coffee beans, brewing methods, and popular coffee recipes.
                It also highlights various types of coffee around the world. You can explore all types of coffee and the price for each one.
                Additionally, I wanted to create a website that could inspire coffee energy in people and offer a variety of coffee types for customers, helping them understand their unique qualities.
                You can click <a target="_blank" href="json/coffeeProducts.json"><strong>here</strong></a> to
                explore my structured JSON file containing this data. In addition, I'm trying to build a website to toward people to the coffee life meditation and mindfulness.

                Besides that, I have strong passion with the coffee beans and I think that can help get more power mental when I was facing with a lot of challenges in life.
                That's also one of the reason made me build a website related to the coffee meditation and also type of coffee beans. Can you click  <a target="_blank" href="json/CoffeeBeans.json"><strong>here</strong></a> to discover more
                about what type of coffee bean make for people mental refreshing. Thank You.
            </p>

            <h4>My Web Development Experience</h4> { }
            <p>
                This website has been an exciting journey that allowed me to practice essential web development skills.
                It was the first time I worked with HTML to structure the content and integrated JSON data to make the site more informative and interactive.
                I learned how to work with <code>title</code> and <code>src</code> attributes to add images, and I also worked with JSON data to make the site visually appealing and fully responsive,
                ensuring a great user experience. I think my web development experience has level up a little since I'm taking the home work 2.
                It was helped me familiar with some of the new concept about React
                and more understand about the Provider Style Coding. For me, I feel that would harder than usual and I think I need to study more from the W3school to prepare for the test1.
            </p>

            <h4> HW 01 Module </h4>
            <p>
                I feel like the  homework was both challenging and valuable in helping me develop a deeper understanding of web design principles.
                I also faced some challenges, such as how to create the title and structure content properly. Some problems got me stuck on this assignment.
                I struggled when trying to move the text to make it more readable.
                Overall, this homework helped me familiarize myself with the syntax of HTML and CSS.
            </p>

            <h4> HW 02 Module </h4>
            <p>
                Thought about expanding assignment explanation for a second
                For my second assignment, I focused on enhancing the Home and Blog pages by updating the content and applying custom CSS styles to improve their visual appeal.
                I successfully implemented responsive images using floats and added personalized background colors to highlight different sections. However,
                I encountered challenges with creating a responsive multi-column layout that shifts from multiple columns on desktop screens to a single column on mobile devices.
                Although I followed a tutorial on building this type of layout, the solution did not work as expected, leaving me confused about how to achieve the desired responsiveness.
            </p>


            <h4> HW 03 Module </h4>
            <p>
                This week, I worked with a lot of new things, such as React Router and functions, which are very useful if I create a professional website in the future.
                Besides that, this week's homework was pretty hard for me because I had trouble with tag conditions and other components.
                Additionally, I struggled with CSS and spent a lot of time styling my components. Regarding the components, I was able to create three: the first one is a property,
                the second one is a different property, and the third one is an empty component.
                Basically, I think Homework 03 was quite challenging and had a lot of requirements. However, I learned a lot of new things through this assignment.
            </p>

            <h4> HW 04 Module and Topic/Relevance </h4>
            <p>
                This week, I worked with something new—React. I had to use a content-generating function and attempt to list multiple images using the map() function
                with key-value pairs. I found this assignment particularly challenging because
                I struggled with properly listing images using return and encountered issues when trying to modify the description and price dynamically in React.
                One of the most difficult parts was displaying the image list using imgObjList.
                It took me a long time to understand how to structure and render the images correctly.
                Additionally, ensuring the UI displayed everything as intended added to the complexity.
                I spent significant time debugging and figuring out how to make everything work smoothly.
            </p>

            <h4> HW 05 Module JS Slideshow </h4>
            <p>
                This week, after spring break, I worked on a JavaScript slideshow. One of the most challenging parts was dealing with AJAX, particularly handling the picture object array, which I found difficult to understand.
                Aside from that, my MakeSlideShow function worked, but I spent a lot of time fixing issues with the forward and back buttons. When I tried to display the price and description using the “Show” button, it didn’t function as expected.
                Additionally, I encountered difficulties loading the imageURL.
                Regarding my slideShow_CGF, the biggest challenge was working with AJAX. I struggled with passing parameters into MakeSlideShow, and it took me a long time to figure it out.
                Ultimately, completing this assignment gave me a better understanding of how a slideshow works and allowed me to practice writing reusable code. Thank you!
            </p>

            <h4> HW 06 JS Object List Component Homework </h4>
            <p>
                This week, I worked on the JS Object List Component Homework, and I found some parts both challenging and valuable. One of the hardest aspects for me was managing and
                manipulating objects within an array. I struggled with accessing and displaying the correct properties dynamically, especially when iterating through the list. At first,
                I found it confusing to properly structure my object data and ensure that each item was rendered correctly in the UI. Additionally, handling events within the component,
                such as updating or filtering the list, took me some time to figure out. I wasn’t sure how to properly link my event listeners to the correct object properties. However, after working through these challenges,
                I gained a much better understanding of how JavaScript handles objects, lists, and dynamic rendering. This assignment really helped reinforce my skills in working with JavaScript objects and event-driven programming.
            </p>


            <h4> HW 07 React Object List Component Homework </h4>
            <p>
                This week, I worked on the React Object List Component Homework. One of the challenges I faced was creating the object list MakeCoffeeListR and passing the file image along with an array of pictures. I was a bit confused
                about how to properly pass the file image as a link.
                I also encountered an issue when trying to display the images, allowing customers to pick an image related to my coffee object.
                One of the key parts of my code was using mymap((coffee, index) = ...), which helped me quickly solve the problem.
                Additionally, I had some trouble understanding a sample deduction of -0.5 points. Regarding the requirement to pass an empty object, I made sure to do so by defining MakeCoffeeListR as a private function and passing an empty object into it.
                I hope I don’t lose points for that.
            </p>


            <h4> HW 08 Input Component Homework </h4>
            <p>
                This week, I worked on the input component homework. There were several parts that confused me, especially the input validation. I wasn’t very clear on which fields were required and which ones were optional.
                I had a few questions—mainly, whether the code I wrote for validating the Date input, makeRadio, and select elements was correct. For me, this assignment was a bit more challenging, but I tried my best to complete it.
                I also ran into some trouble when styling my editAreaC with CSS. While the style looks okay for now, I’m still not fully satisfied with how it turned out. I think I need to spend more time learning how to style it properly.
                Overall, I found the input validation, makeRadio, and Select List parts a bit difficult to understand. I’m going to keep working on it and try to fully figure out what the assignment is asking me to do.
            </p>


            <h4> HW 09 Editable List Component Homework </h4>
            <p>
                This week, I worked on the Editable List Component, and I found it to be one of the most challenging assignments of the semester. I successfully loaded the initial JSON data and displayed my full coffee list. When I clicked the Edit and Insert buttons, I was able to add new objects and edit existing ones without issues.
                However, I ran into a design challenge. When triggering the Edit or Insert actions, the form that appears is much larger than I expected. I would prefer it to be a smaller, more compact box that fits neatly within the layout.
                As for the MakeCrudList function, I had a bit of a hard time fully understanding how it all worked at first. This final homework really felt like a combination of everything we’ve learned so far, and it definitely felt more complex and heavy compared to previous tasks.
            </p>







        </div>


    );
}