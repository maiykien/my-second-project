"use strict";

function MakeEditList({ objList, inputSpecs, displayTemplate }) {

    function applyTemplate(template, obj) {
        return eval("`" + template + "`");
    }

    function MakeChildEle(obj, inputSpecs, displayTemplate) {

        for (let spec of inputSpecs) {
            if (!obj.hasOwnProperty(spec.fieldName)) {
                const errorMsg = `function MakeUserEle needs an 'obj' with property ${spec.fieldName}`;
                alert(errorMsg);
                throw new Error(errorMsg);
            }
        }

        const eleDiv = MakeTag({ htmlTag: "div", cssClass: "ele" });

        const eleInfo = MakeTag({
            htmlTag: "div",
            cssClass: "eleInfo",
            parent: eleDiv
        });

        // -- IMAGE HANDLING WITH FALLBACK --
        const img = new Image();
        img.className = "coffee-image";
        img.alt = obj.name || "preview";

        img.onerror = () => {
            img.src = "pics/default.jpg";
        };
        img.src = obj.image && obj.image !== "undefined" && obj.image !== "null" ? obj.image : "pics/default.jpg";

        eleInfo.appendChild(img);

        // -- APPLY TEMPLATE (REMOVE <img> IF INCLUDED IN DISPLAYTEMPLATE) --
        const restHTML = applyTemplate(displayTemplate, obj);
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = restHTML;

        const imgInTemplate = tempDiv.querySelector("img");
        if (imgInTemplate) imgInTemplate.remove();

        while (tempDiv.firstChild) {
            eleInfo.appendChild(tempDiv.firstChild);
        }

        function refreshChildEle() {
            const newHTML = applyTemplate(displayTemplate, obj);
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = newHTML;

            const imgInTemplate = tempDiv.querySelector("img");
            if (imgInTemplate) imgInTemplate.remove();

            while (eleInfo.childNodes.length > 1) {
                eleInfo.removeChild(eleInfo.lastChild);
            }

            while (tempDiv.firstChild) {
                eleInfo.appendChild(tempDiv.firstChild);
            }
        }

        const editButton = MakeTag({
            htmlTag: "div",
            cssClass: "clickable",
            innerHTML: "Edit",
            parent: eleDiv
        });

        editButton.onclick = function () {
            if (!isEditing) {
                editArea = MakeEditArea({
                    inputSpecs,
                    successCallBack: editSuccess,
                    cancelCallBack: cancel,
                    editObj: obj
                });
                editContainer.appendChild(editArea);
                isEditing = true;
            }
        };

        function editSuccess(inpObj) {
            isEditing = false;
            deleteEditArea();
            refreshChildEle();
        }

        return eleDiv;
    }

    // =============== Main ===============
    let editArea;
    let isEditing = false;

    const listDiv = MakeTag({
        htmlTag: "div",
        cssClass: "crudList"
    });

    const editContainer = MakeTag({
        htmlTag: "div",
        parent: listDiv
    });

    const insertButton = MakeTag({
        htmlTag: "button",
        innerHTML: "Insert",
        parent: listDiv
    });

    insertButton.onclick = function () {
        let obj = {};
        for (let spec of inputSpecs) {
            obj[spec.fieldName] = "";
        }

        if (!isEditing) {
            editArea = MakeEditArea({
                inputSpecs,
                successCallBack: insertSuccess,
                cancelCallBack: cancel,
                editObj: obj
            });
            editContainer.appendChild(editArea);
            isEditing = true;
        }
    };

    function insertSuccess(newObj) {
        isEditing = false;
        deleteEditArea();

        const newDiv = MakeChildEle(newObj, inputSpecs, displayTemplate);
        listDiv.appendChild(newDiv);
    }

    function deleteEditArea() {
        if (editArea && editArea.parentNode) {
            editArea.parentNode.removeChild(editArea);
        }
    }

    function cancel() {
        isEditing = false;
        deleteEditArea();
    }

    for (const myObj of objList) {
        listDiv.appendChild(MakeChildEle(myObj, inputSpecs, displayTemplate));
    }

    return listDiv;
}
