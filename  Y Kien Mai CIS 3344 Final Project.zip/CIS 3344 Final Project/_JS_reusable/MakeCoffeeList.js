"use strict";

function MakeCoffeeList({coffeeList = [{}], title = "Empty Coffee List", styleCoffee = "No Style Coffee"}) {

    function MakeCoffee({
        nameCoffee = "",
        imageURL = "",
        price = 0,
        description = "",
        coffeeImageList = [{ "display": "Coffee Image Not Available now", "val": 1 }],
        initialCoffeeCondition = 1
    }) {

        if (!imageURL) {
            imageURL = "pics/NoImage.jpg"; // Provide a fallback image
        }
        
        console.log(`Creating Coffee: ${nameCoffee}, Image URL: ${imageURL}`);


        var coffeeObj = document.createElement("div"); // Creates a new div element
        coffeeObj.classList.add("coff"); // Adds the CSS class "coff" to the div

        // Set the inner HTML with dynamic values
        coffeeObj.innerHTML = `
            <h2>${nameCoffee}</h2>
            <p class="coffee-desc">${description}</p>
            <p class="coffee-price">Price: $${price.toFixed(2)}</p>
            <img class="coffee-img" src="${imageURL}" alt="${nameCoffee}">
            <div class="coffee-selection">
                <label>Pick Type of Coffee:</label>
                <select class="selectTypeCoffee">
                </select>
            </div>
            <br/>
            <button class='titleButtonClass'>Modify Description</button>
            <input class='newDescriptionInputClass' placeholder="Enter new description"/> <br/>
            <button class='PriceButtonClass'>Change Price By</button>
            <input class='priceFactorInputClass' placeholder="Enter price change"/>
            <br/><br/>
        `;

        // This one for detches various elements from the newly created 

        var coffeeDesc = coffeeObj.getElementsByClassName("coffee-desc")[0];
        var coffeePrice = coffeeObj.getElementsByClassName("coffee-price")[0];
        var coffeeImg = coffeeObj.getElementsByClassName("coffee-img")[0];
        var selectTypeCoffee = coffeeObj.getElementsByClassName("selectTypeCoffee")[0];
        var descriptionButton = coffeeObj.getElementsByClassName("titleButtonClass")[0];
        var newDescriptionInput = coffeeObj.getElementsByClassName("newDescriptionInputClass")[0];
        var priceButton = coffeeObj.getElementsByClassName("PriceButtonClass")[0];
        var priceFactor = coffeeObj.getElementsByClassName("priceFactorInputClass")[0];

        for (var opt of coffeeImageList) {
            var newOpt = document.createElement("option");
            newOpt.innerHTML = opt.display; 
            newOpt.value = opt.val; 
            selectTypeCoffee.appendChild(newOpt);
        }

        selectTypeCoffee.value = initialCoffeeCondition;

        descriptionButton.onclick = function () {
            var newDesc = newDescriptionInput.value.trim();
            if (newDesc) {
                coffeeDesc.innerHTML = newDesc;
            }
        };

        // Event listener to change coffee price when button is clicked 
        priceButton.onclick = function () {
            var changeAmount = parseFloat(priceFactor.value);
            if (!isNaN(changeAmount) && priceFactor.value.trim() !== "") {
                price += changeAmount;
                coffeePrice.innerHTML = `Price: $${price.toFixed(2)}`;
            } else {
                alert("Please enter a valid number for price change.");
            }
        };
        
        // Event listener to change coffee price when button is clicked
        selectTypeCoffee.onchange = function () {
            var newSrc = selectTypeCoffee.value; // Converts input to a number
            if (newSrc) {
                coffeeImg.src = newSrc;
            }
        };

        return coffeeObj; 
    }

    var coffeeListComp = document.createElement("div");
    coffeeListComp.classList.add("coffList");

    coffeeListComp.innerHTML = `
        <h2>
            ${title} </br>
            ${styleCoffee}
            &nbsp; 
            <button class="priceSortBtnC">Sort By Price</button>
            &nbsp; 
            <button class="DescSortBtnC">Sort By Description</button>
        </h2>
        <div class="listAreaC"></div>
    `;

    var priceSortBtn = coffeeListComp.getElementsByClassName("priceSortBtnC")[0];
    var descSortBtn = coffeeListComp.getElementsByClassName("DescSortBtnC")[0];
    var listArea = coffeeListComp.getElementsByClassName("listAreaC")[0];

    // Event listener for sorting by description
    priceSortBtn.onclick = function () {
        jsSort(coffeeList, "price", "NUMBER");
        refreshCoffeeList(); // Refreshes the coffee list after sorting
    }

    descSortBtn.onclick = function () {
        jsSort(coffeeList, "description", "TEXT");
        refreshCoffeeList();
    }

    function refreshCoffeeList() {
        listArea.innerHTML = "";

        for (var coffObj of coffeeList) { 
            listArea.appendChild(MakeCoffee(coffObj));
        }
    }

    refreshCoffeeList();  // Initial call to populate the list

    return coffeeListComp; // Returns the full coffee list component
}