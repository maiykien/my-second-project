"use strict";
function MakeCrudList({
    title = "Untitled List",
    objList = [{ field1: "no value" }],
    inputSpecs = [{
        prompt: "Field One: ",
        fieldName: "",
        dataType: "string",
        minLen: 1,
        maxLen: 10
    }],
    displayTemplate = "Empty Display Template: ${obj.field1}"
}) {

    let editArea;
    let isEditing = false;

    function applyTemplate(template, obj) {
        var result = eval("`" + template + "`");
        return result;
    }

    function deleteEditArea() {
        if (editArea?.parentNode) {
            editArea.parentNode.removeChild(editArea);
        }
    }

    function cancel() {
        isEditing = false;
        deleteEditArea();
    }

    function MakeChildEle(obj) {
        const eleDiv = MakeTag({ htmlTag: "div", cssClass: "ele" });

        const eleInfo = MakeTag({
            htmlTag: "div",
            cssClass: "eleInfo",
            innerHTML: applyTemplate(displayTemplate, obj),
            parent: eleDiv
        });

        const refreshChildEle = () => {
            eleInfo.innerHTML = applyTemplate(displayTemplate, obj);

            const imgs = eleInfo.querySelectorAll("img");
            imgs.forEach(img => {
                img.onerror = () => {
                    img.onerror = null;
                    img.src = "pics/default.jpg";
                };
            });
        };

        refreshChildEle();

        // Edit Button
        const editButton = MakeTag({
            htmlTag: "div",
            cssClass: "clickable",
            innerHTML: "Edit",
            parent: eleDiv
        });

        editButton.onclick = () => {
            if (!isEditing) {
                editArea = MakeEditArea({
                    inputSpecs,
                    successCallBack: editSuccess,
                    cancelCallBack: cancel,
                    editObj: obj
                });
                editContainer.appendChild(editArea);
                isEditing = true;
            }
        };

        function editSuccess() {
            isEditing = false;
            deleteEditArea();
            refreshChildEle();
        }

        // Delete Button
        const deleteButton = MakeTag({
            htmlTag: "button",
            cssClass: "clickable",
            innerHTML: "&times;",
            parent: eleDiv
        });

        deleteButton.onclick = () => {
            const index = objList.indexOf(obj);
            if (index > -1) {
                objList.splice(index, 1);
                eleDiv.remove();
            }
        };

        return eleDiv;
    }

    const listDiv = MakeTag({ htmlTag: "div", cssClass: "crudList" });

    MakeTag({
        htmlTag: "h2",
        innerHTML: title,
        parent: listDiv
    });

    const editContainer = MakeTag({ htmlTag: "div", parent: listDiv });

    const insertButton = MakeTag({
        htmlTag: "button",
        innerHTML: "Insert",
        parent: listDiv
    });

    insertButton.onclick = function () {
        document.querySelectorAll(".editAreaC").forEach(e => e.remove());
        let editBox = MakeEditArea({
            inputSpecs,
            isEditMode: false,
            editObj: {},
            successCallBack: function (newObj) {
                insertSuccess(newObj);
                editBox.remove();
            },
            cancelCallBack: function () {
                editBox.remove();
            }
        });

        const crudList = document.querySelector(".crudList");
        crudList.prepend(editBox);

        insertButton.parentElement.appendChild(editBox);
    };

    function insertSuccess(newObj) {
        isEditing = false;
        deleteEditArea();

        const newDiv = MakeChildEle(newObj);
        listDiv.appendChild(newDiv);

        objList.push(newObj);
    }

    for (const obj of objList) {
        listDiv.appendChild(MakeChildEle(obj));
    }

    return listDiv;
}
