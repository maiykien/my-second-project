"use strict";

// Validate.js with Radio and Select validation handling default values
var Validate = {};

// Validates a number input with optional min and max values
Validate.Number = (inputVal, isRequired, minValue = -Infinity, maxValue = Infinity) => {
    if (isRequired && inputVal.length === 0) {
        return "Required";
    }

    // Check  if input is not a valid number
    if (isNaN(inputVal)) {
        return "Error. Not a valid number.";
    }

    // Check if number is less than the minimum allowed value
    const numVal = Number(inputVal);
    if (numVal < minValue) {
        return `Error: Value must be greater than or equal to ${minValue}.`;
    }

    // Check if number is greater than the maximum allowed value
    if (numVal > maxValue) {
        return `Error: Value must be less than or equal to ${maxValue}.`;
    }

    return ""; // No error.
};

// Validates an integer input with optional min and max values
Validate.Integer = (inputVal, isRequired, minValue = -Infinity, maxValue = Infinity) => {
    // Check if the field is required and empty
    if (isRequired && inputVal.toString().trim().length === 0) {
        return `Error: This field is must be in ${minValue} and ${maxValue}`;
    }

    // Check if the input is a number
    if (!Number.isNaN(Number(inputVal))) {
        var numVal = Number(inputVal);
        
        // Check if it is an integer
        if (Number.isInteger(numVal)) {
            // Validate range
            if (numVal < minValue) {
                return `Error: Value must be greater than or equal to ${minValue}.`;
            }
            if (numVal > maxValue) {
                return `Error: Value must be less than or equal to ${maxValue}.`;
            }
            return ""; // No error, valid integer
        } else {
            return "Error: You entered a number, but it's not an integer.";
        }
    }

    return "Error: Not a valid integer (not a number either).";
};

// Validate String function with min/max length
Validate.String = (inputVal, isRequired, maxLen, minLen = 1) => {
    if (isRequired && inputVal.length === 0) {
        return "Error: This field is required.";
    }

    // Check if input is shorter than the minimum required length
    if (inputVal.length < minLen && isRequired) {
        return `Error: Input must be at least ${minLen} characters long.`;
    } else if (isRequired === false) {
        // If not required, skip the other checks. 
        return "";
    }

    // Check if input exceeds the maximum allowed langth
    if (maxLen && inputVal.length > maxLen) {
        return `Error: Please shorten your input to ${maxLen} characters or fewer.`;
    }



    return ""; // No error means input passed validation.
};

// Validate whether a required has a value
Validate.RequiredField = (inputVal, isRequired) => {
    if (isRequired && inputVal.length === 0) {
        return "Selection Required";
    }
    return ""; // Valid if not required or has value
};


// Validates a <select> dropdown input
Validate.Select = (selectElement, isRequired, defaultValue = "") => {
    if (!selectElement) {
        return {
            error: "Select element is missing.",
            value: defaultValue
        };
    }

    let selectedValue = selectElement.value.trim();

    // If the field is required but nothing is selected
    if (isRequired && selectedValue.length === 0) {
        return {
            error: "Please choose an option.",
            value: defaultValue
        };
    }

    return {
        error: "",
        value: selectedValue || defaultValue  // Return selected value or default value
    };
    


};
