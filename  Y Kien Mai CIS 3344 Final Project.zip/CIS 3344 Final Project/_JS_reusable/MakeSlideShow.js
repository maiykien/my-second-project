"use strict";

// Function to create a slideshow compoent 
function MakeSlideShow({
    title = "Welcome To My Slide Show Default",  // That would be the default title if none is provided. 
    picObjList = [ // Default list of images if none is provided. 
        { 
            imageURL: "pics/NoImage.jpg",
            caption: "Default Image",
            infor: "This is a my default infor."
        }
    ],

    transitionEffect = "fade" // Default transistion effect

}) {

    // Check localStorage for saved image index and use it; 
    var savedPicNum = localStorage.getItem("currentImageIndex");
    var picNum = savedPicNum ? parseInt(savedPicNum) : 0;

    // This will be create the main slideshow container
    var slideShow = document.createElement("div");
    slideShow.classList.add("slideShow");

    // Set up the HTML structure inside the slideshow
    slideShow.innerHTML = `
        <h2>${title}</h2>
        <img class="myImageC" />
        <p class="captionCoffee1"></p> 
        <p>
            <button class="showButtonC">Show</button>
        </p>

        <!-- Initially hidden div for price and category -->
        <div class="hideShowInfoC hide">
            <p class="infoText"></p>
        </div>

        <div>
            <button class="backButtonC">&lt;</button> &nbsp;
            <button class="fwdButtonC">&gt;</button>
        </div>
    `;

    // Get references to important elements inside the slideshow. 
    var myImage = slideShow.getElementsByClassName("myImageC")[0];
    var captionCoffee1 = slideShow.getElementsByClassName("captionCoffee1")[0];
    var backButton = slideShow.getElementsByClassName("backButtonC")[0];
    var fwdButton = slideShow.getElementsByClassName("fwdButtonC")[0];

    var showButton = slideShow.getElementsByClassName("showButtonC")[0];
    var hideShowInfo = slideShow.getElementsByClassName("hideShowInfoC")[0];
    var infoText = slideShow.getElementsByClassName("infoText")[0];

    // Initially hide the price and category (hidden state)
    hideShowInfo.classList.add("hide");

     // When Show button is clicked
     function applyTransitionEffect() {
        // Apply smooth transition styles
        myImage.style.transition = "all 0.5s ease-in-out"; 
    
        if (transitionEffect === "fade") {
            myImage.style.opacity = 0; // Hide the image
            setTimeout(() => {
                myImage.style.opacity = 1; // Fade it back in smoothly
            }, 300);
        } 
        else if (transitionEffect === "slide") {
            myImage.style.transform = "translateX(-100%)"; // Slide out
            setTimeout(() => {
                myImage.style.transform = "translateX(0)"; // Slide in smoothly
            }, 300);
        } 
    
        console.log("Transition applied:", transitionEffect);
    }


   // Function to update the displayed image and text
    function display() {


        myImage.src = picObjList[picNum]?.imageURL || "pics/NoImage.jpg";
        captionCoffee1.textContent = picObjList[picNum]?.caption || "No caption available";
        infoText.innerHTML = picObjList[picNum]?.infor || "No additional info available.";
    
        // Save the current image index to localStorage
        localStorage.setItem("currentImageIndex", picNum);
        
        // Disable or enable navigation buttons based on the current image index.
        backButton.disabled = picNum === 0;
        fwdButton.disabled = picNum === picObjList.length - 1;
        
        // That would be hide extra infor initialy
        hideShowInfo.classList.add("hide");
        showButton.textContent = "Show";

        // Apply transistion effect. 
        applyTransitionEffect();
    }

    // This function will be make transistion effect
    display();


    // Toggle extra information visibility when the Show button
    showButton.onclick = function () {
        if (hideShowInfo.classList.contains("hide")) {
            hideShowInfo.classList.remove("hide"); // Show price and category
            showButton.textContent = "Less"; // Change button text to "Less"
        } else {
            hideShowInfo.classList.add("hide"); // Hide price and category
            showButton.textContent = "Show"; // Change button text back to "Show"
        }
    };

    // Navigate to the next image when the forward button is clicked
    fwdButton.onclick = function () {
        if (picNum < picObjList.length - 1) {
            picNum++;
            display();
        }
    };

    // Navigate to the previous image when the back button is clicked. 
    backButton.onclick = function () {
        if (picNum > 0) {
            picNum--;
            display();
        }
    };

    // That would be control of the image index. 
    slideShow.setPicNum = function (newNum) {
        if (newNum >= 0 && newNum < picObjList.length) {
            picNum = newNum;
            display();
        }
    };

    return slideShow; // Return the complete slideshow component. 
    
}
