"use strict";

// Function to create a radio group for coffee-related selections
function MakeRadio({
    prompt = "Select your preferred coffee option:",
    choices = ["Espresso", "Latte", "Cappuccino"],
    selected = "" }) {

    var frm = document.createElement("form"); // Create a <form> element
    frm.classList.add("editAreaC");
    frm.value="";

    // Add the prompt
    var promptElement = document.createElement("p");
    promptElement.textContent = prompt;
    frm.appendChild(promptElement);

    // Create a container for the radio buttons
    var radioGroup = document.createElement("div");
    radioGroup.classList.add("radio-group"); // Apply the radio-group styling

    // Generate radio buttons dynamically
    for (var choice of choices) {
        var label = document.createElement("label");

        var radioInput = document.createElement("input");
        radioInput.type = "radio";
        radioInput.name = "coffeeChoice"; // All radios need the same name for grouping
        radioInput.value = choice;

        if (choice === selected) {
            radioInput.checked = true; // Preselect the chosen option
            frm.value = choice; // Store the value in the form
        }

        label.appendChild(radioInput);
        label.append(`${choice}`); // Space before text
        radioGroup.appendChild(label);
    }

    // Append radio group to form
    frm.appendChild(radioGroup);

    // Update form value when a radio button is selected
    frm.addEventListener("change", function () {
        frm.value = frm.querySelector('input[name="coffeeChoice"]:checked').value;
    });

    return frm;
}