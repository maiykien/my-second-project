"use strict"

function MakeEditArea({ inputSpecs, successCallBack, cancelCallBack, editObj = {}, isEditMode = false }) {

    var errorMsg = "";

    if (!inputSpecs || !inputSpecs[0]) {
        errorMsg += "MakeEditArea did not receive a parameter property named 'inputSpecs'\n" +
            "that has at least one object (that defines one input field). <br/><br/>";
    }

    if (!successCallBack || !(successCallBack instanceof Function)) {
        errorMsg += "MakeEditArea did not receive a parameter property named 'successCallBack',\n" +
            "a Consumer function that will be called (passing an object full of user entered data)\n" +
            "if the user clicks 'Submit' and all the inputs validate. <br/><br/>";
    }

    if (!cancelCallBack || !(cancelCallBack instanceof Function)) {
        var errorMsg = "MakeEditArea did not receive a parameter property named 'cancelCallBack',\n" +
            "a Consumer function that will be called if the user clicks 'Cancel'.\n" +
            "(no input will be passed to the cancel call back function). <br/><br/>";
    }

    if (errorMsg.length > 0) {
        alert(errorMsg);
        throw errorMsg;
    }

    var editDiv = document.createElement("div");

    editDiv.classList.add("editAreaC");

    // This will show just a simple form without unnecessary wrappers for Insert/Edit modes
    editDiv.innerHTML = 
    `<h2 class="formTitleC">Insert/Edit Bean/Coffee product</h2>
    <div class="rowsC"></div>
    <button class="saveButtonC">Submit</button>
    <button class="cancelButtonC">Cancel</button>
    <span class="recLevelMsgC"></span>`;


    var rows = editDiv.getElementsByClassName("rowsC")[0];
    var saveButton = editDiv.getElementsByClassName("saveButtonC")[0];
    var cancelButton = editDiv.getElementsByClassName("cancelButtonC")[0];
    var recLevelMsg = editDiv.getElementsByClassName("recLevelMsgC")[0];

    // Loop through inputSpecs to create form fields
    for (var spec of inputSpecs) {
        var rowDiv = document.createElement("div");
        rowDiv.classList.add("row");
        rowDiv.innerHTML = `<span class="prompt">${spec.prompt}</span>`;

        // Create input fields based on dataType
        if (spec.dataType === "radio") {
            spec.inputTag = MakeRadio({
                prompt: spec.prompt,
                choices: spec.choices,
                selected: spec.selected
            });

            rowDiv.appendChild(spec.inputTag);
        } else if (spec.dataType === "select") {
            spec.inputTag = document.createElement("select");
            for (var choice of spec.choices) {
                let option = document.createElement("option");
                option.value = choice;
                option.innerHTML = choice;
                if (choice === spec.selected) {
                    option.selected = true;
                }
                spec.inputTag.appendChild(option);
            }
            rowDiv.appendChild(spec.inputTag);

            
        } else {
            spec.inputTag = document.createElement("input");
            spec.inputTag.type = spec.dataType === "date" ? "date" : "text";
            spec.inputTag.value = editObj[spec.fieldName] || ""; // Use editObj if available (Edit Mode)
            rowDiv.appendChild(spec.inputTag);
        }

        spec.errorMsg = document.createElement("span");
        spec.errorMsg.classList.add("error");
        rowDiv.appendChild(spec.errorMsg);
        rows.appendChild(rowDiv);
    }

    // Handle Save button logic
    saveButton.onclick = function () {
        var allErrors = "";
        for (var spec of inputSpecs) {
            if (spec.dataType === "radio") {
                spec.errorMsg.innerHTML = Validate.RequiredField(spec.inputTag.value, spec.isRequired);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else if (spec.dataType === "string") {
                spec.errorMsg.innerHTML = Validate.String(spec.inputTag.value, spec.isRequired, spec.maxLen, spec.minLen);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else if (spec.dataType === "number") {
                spec.errorMsg.innerHTML = Validate.Number(spec.inputTag.value, spec.isRequired, spec.min, spec.max);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else if (spec.dataType === "date") {
                spec.errorMsg.innerHTML = Validate.RequiredField(spec.inputTag.value, spec.isRequired);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else if (spec.dataType === "select") {
                spec.errorMsg.innerHTML = Validate.RequiredField(spec.inputTag.value, spec.isRequired);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else if (spec.dataType === "integer") {
                spec.errorMsg.innerHTML = Validate.Integer(spec.inputTag.value, spec.isRequired, spec.minLen, spec.maxLen);
                allErrors += spec.errorMsg.innerHTML;
                editObj[spec.fieldName] = spec.inputTag.value;
            } else {
                spec.errorMsg.innerHTML = "";
                editObj[spec.fieldName] = spec.inputTag.value;
            }
        }

        if (allErrors.length > 0) {
            recLevelMsg.innerHTML = "Please Try Again";
            return;
        }
        recLevelMsg.innerHTML = "Success!";
        successCallBack(editObj);
    };

    // Function to clear form inputs
    function clearAll() {
        for (var spec of inputSpecs) {
            spec.inputTag.value = "";
        }
        recLevelMsg.innerHTML = "";
    }

    cancelButton.onclick = function () {
        clearAll();
        cancelCallBack();
    };

    return editDiv;
}
