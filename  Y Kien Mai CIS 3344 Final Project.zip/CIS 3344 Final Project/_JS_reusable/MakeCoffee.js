"use strict"; // Enables strict mode to catch common coding errors

function MakeCoffee({
    nameCoffee = "Unknown Coffee",
    imageURL = "Unknown Image",
    price = 0,
    description = "N/A",
    coffeeList = [{ "display": "Coffee Image Not Available now", "val": 1 }],
    initialCoffeeCondition = 1
}) {
    var coffeeObj = document.createElement("div"); // Creates a new div element
    coffeeObj.classList.add("coff"); // Adds the CSS class "coff" to the div

    // Set the inner HTML with dynamic values
    coffeeObj.innerHTML = `
        <h2>${nameCoffee}</h2>
        <p class="coffee-desc">${description}</p>
        <p class="coffee-price">Price: $${price.toFixed(2)}</p>
        <img class="coffee-img" src="${imageURL}" alt="${nameCoffee}">
        <div class="coffee-selection">
            <label>Pick Type of Coffee:</label>
            <select class="selectTypeCoffee">
            </select>
        </div>
        <br/>
        <button class='titleButtonClass'>Modify Description</button>
        <input class='newDescriptionInputClass' placeholder="Enter new description"/> <br/>
        <button class='PriceButtonClass'>Change Price By</button>
        <input class='priceFactorInputClass' placeholder="Enter price change"/>
        <br/><br/>
    `;

    // Retrieve references to elements inside the coffee div
    var coffeeDesc = coffeeObj.getElementsByClassName("coffee-desc")[0];
    var coffeePrice = coffeeObj.getElementsByClassName("coffee-price")[0];
    var coffeeImg = coffeeObj.getElementsByClassName("coffee-img")[0];
    var selectTypeCoffee = coffeeObj.getElementsByClassName("selectTypeCoffee")[0];
    var descriptionButton = coffeeObj.getElementsByClassName("titleButtonClass")[0];
    var newDescriptionInput = coffeeObj.getElementsByClassName("newDescriptionInputClass")[0];
    var priceButton = coffeeObj.getElementsByClassName("PriceButtonClass")[0];
    var priceFactor = coffeeObj.getElementsByClassName("priceFactorInputClass")[0];

    // Populate the select dropdown with coffee types
    for (var opt of coffeeList) {
        var newOpt = document.createElement("option");
        newOpt.innerHTML = opt.display; 
        newOpt.value = opt.val; 
        selectTypeCoffee.appendChild(newOpt);
    }
    
    // Set the initial selected value
    selectTypeCoffee.value = initialCoffeeCondition;

    // Function to update description
    descriptionButton.onclick = function () {
        var newDesc = newDescriptionInput.value.trim();
        if (newDesc) {
            coffeeDesc.innerHTML = newDesc;
        }
    };

    // Function to update price
    priceButton.onclick = function () {
        var changeAmount = parseFloat(priceFactor.value);
        if (!isNaN(changeAmount) && priceFactor.value.trim() !== "") {
            price += changeAmount;
            coffeePrice.innerHTML = `Price: $${price.toFixed(2)}`;
        } else {
            alert("Please enter a valid number for price change.");
        }
    };

    // Function to update coffee image
    selectTypeCoffee.onchange = function () {
        var newSrc = selectTypeCoffee.value;
        if (newSrc) {
            coffeeImg.src = newSrc;
        }
    };

    return coffeeObj; // Returns the coffee object div
}
