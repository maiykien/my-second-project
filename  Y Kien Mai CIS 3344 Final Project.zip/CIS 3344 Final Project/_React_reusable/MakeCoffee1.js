"use strict"; // Prevent browser from globally auto-declaring variables

function MakeCoffee1({
    nameCoffee = "Unknown Coffee", // I will put the default name
    imageURL = "Unknown Image", 
    Theprice = 0, // Default price set to 0
    Thedescription = "N/A", // Default descript if none is provided.
    coffeeList = [{ "display": "Coffee Image Not Available", "val": "" }] // Default coffee list with a place holder.
}) {

    // Helper function to format currency
    function formatCurrency(numStr) {
        var num = Number(numStr);
        return num.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 });
    }

    // State for the image, description, and price
    const [selectedImage, setSelectedImage] = React.useState(imageURL);
    const [description, setDescription] = React.useState(Thedescription);
    const [descriptionInput, setDescriptionInput] = React.useState("");
    const [price, setPrice] = React.useState(Theprice);
    const [priceInput, setPriceInput] = React.useState("");

    // Function to change the description
    function changeDescription() {
        setDescription(descriptionInput);
    }

    // Function to change the price
    function changePrice() {
        var n = Number(priceInput);
        if (isNaN(n)) {
            console.log("Invalid input: Please enter a numeric value.");
            return;
        }
        console.log("Changing price by this rate: " + n);
        setPrice(price + n);
    }

    // Function to change the coffee image
    function changeImage(event) {
        setSelectedImage(event.target.value);
    }

    console.log("Selected Image:", selectedImage);
    console.log("Coffee List:", coffeeList);

    return (
        <div className="coff1"> {/* Create the name with coff1 to style my page*/}
        {/* Displays selected coffee image if available*/}
            {selectedImage && <img src={selectedImage} alt="Coffee Image" />}<br />
            <p>
            Name: {nameCoffee} <br /> {/* I will display the coffee name*/}
            Price: {formatCurrency(price)} <br /> {/* We will need to display the format price*/}
            Description: {description} <br />

             {/* I need dropdown for selecting a coffee image */}
             <label>Select Coffee Image:</label>
            <select value={selectedImage} onChange={changeImage}>
                {coffeeList.map((coffee, index) => (
                    <option key={index} value={coffee.val}>{coffee.display}</option>
                ))}  
            </select>
            
            {/* Button to trigger a function to change the description */}
            <button onClick={changeDescription}>Change Description To:</button>
            <input value={descriptionInput} onChange={e => setDescriptionInput(e.target.value)} /> <br />
            {/* Button to trigger a function to change the price */}
            <button onClick={changePrice}>Change Price To:</button>
            <input value={priceInput} onChange={e => setPriceInput(e.target.value)} /> <br />
            </p>
        </div>
    );
}