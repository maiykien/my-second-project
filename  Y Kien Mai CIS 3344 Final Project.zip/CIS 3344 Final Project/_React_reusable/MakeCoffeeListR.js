"use strict"

function MakeCoffeeListR({ coffeeList = [{}], title = "My third empty object", styleCoffee = " Empty Style" }) {

    function MakeCoffeeR({
        nameCoffee = "",
        imageURL = "",
        Theprice = 0,
        Thedescription = "",
        coffeePics = []
    }) {
        if (!imageURL) {
            imageURL = "pics/NoImage.jpg"; // Provide a fallback image
        }

        // Helper function to format currency
        function formatCurrency(numStr) {
            var num = Number(numStr);
            return num.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 });
        }

        // State for the image, description, and price
        const [selectedImage, setSelectedImage] = React.useState(imageURL);
        const [description, setDescription] = React.useState(Thedescription);
        const [descriptionInput, setDescriptionInput] = React.useState("");
        const [price, setPrice] = React.useState(Theprice);
        const [priceInput, setPriceInput] = React.useState("");

        // Function to change the description
        function changeDescription() {
            setDescription(descriptionInput);
        }

        // Function to change the price
        function changePrice() {
            var n = Number(priceInput);
            if (isNaN(n)) {
                console.log("Invalid input: Please enter a numeric value.");
                return;
            }
            console.log("Changing price by this rate: " + n);
            setPrice(price + n);
        }

        // Function to change the coffee image
        function changeImage(event) {
            setSelectedImage(event.target.value);
        }

        return (
            <div className="coff1">
                {selectedImage && <img src={selectedImage} alt="Coffee Image" />}<br />
                <p>
                    Name: {nameCoffee} <br />
                    Price: {formatCurrency(price)} <br />
                    Description: {description} <br />
                    <label>Select Coffee Image:</label>
                    <select value={selectedImage} onChange={changeImage}>
                        {coffeePics.map((coffee, index) => (
                            <option key={index} value={coffee.val}>{coffee.display}</option>
                        ))}
                    </select>

                    <button onClick={changeDescription}>Change Description To:</button>
                    <input value={descriptionInput} onChange={e => setDescriptionInput(e.target.value)} /> <br />
                    <button onClick={changePrice}>Change Price To:</button>
                    <input value={priceInput} onChange={e => setPriceInput(e.target.value)} /> <br />
                </p>
            </div>
        );
    }

    // Function to sort by property (price or description)
    function sortByProp(propName, sortType) {
        console.log(`Sorting by: ${propName}, Type: ${sortType}`);

        // Sort the coffee list using jsSort and sortOrder
        jsSort(coffeeListState, propName, sortType);

        // Create a copy of the list to avoid directly mutating state
        let listCopy = JSON.parse(JSON.stringify(coffeeListState));
        
        // Update the state with the sorted list
        setCoffeeListState(listCopy);
    }

    // CoffeeList Entry Point 
    const [coffeeListState, setCoffeeListState] = React.useState(coffeeList);

    // Render the Coffee List and Sort Buttons
    return (
        <div className="coffList">
            <h2>{title}</h2>
            <h2>{styleCoffee}</h2>
            <h2>
                <button onClick={() => sortByProp("price", "NUMBER")}>
                    Sort By Price
                </button>
                &nbsp;
                <button onClick={() => sortByProp("description", "TEXT")}>
                    Sort By Description
                </button>
            </h2>

            {coffeeListState.map((coff1, idx) => (
                <MakeCoffeeR key={idx}
                    imageURL={coff1.image}
                    nameCoffee={coff1.name || "Unknown"}
                    Theprice={coff1.price || 0}
                    Thedescription={coff1.description || "No description available"}
                    coffeePics={coff1.pics}
                />
            ))}
        </div>
    );
}